/*package com.springboot.tryouts.tryouts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TryoutsApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/