package com.springboot.tryouts.demo.service;

import com.springboot.tryouts.demo.model.Course;

public interface CourseService {

	public Course getCourseById(int id);
}
