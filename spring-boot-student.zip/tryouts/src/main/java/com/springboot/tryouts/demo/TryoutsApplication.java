package com.springboot.tryouts.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TryoutsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TryoutsApplication.class, args);
	}

}
